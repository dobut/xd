/*
David Breeden
Chapter 16 HW 1
3/26/28
Inventory.cpp

Getting the decimals to all be to two spaces and not messing up the other numbers was giving me a lot of trouble so I just left it be :/
*/

#include <iostream>
#include <string>
#include <vector>
#include "Item.h"

using namespace std;

// I just put the sort here in main because putting it in the class was way more complicated and it isn't reliant on a class to begin with
template <class t>
void sort(vector<t> &a) {
	int smallestIndex;
	Item temp;

	for (size_t index = 0; index < a.size() - 1; index++) {
		smallestIndex = index;
		for (size_t location = index + 1; location < a.size(); location++)
		{
			if (a[location] < a[smallestIndex])
			{
				smallestIndex = location;
			}
		}
		temp = a[smallestIndex];

		a[smallestIndex] = a[index];
		a[index] = temp;
	}
}

int main() {
	Item i;
	vector<Item> v;
	float total = 0;

	while (i.getId() != -1) {
		cout << "Item info? ";
		cin >> i;
		cout << endl;
		v.push_back(i);
	}

	sort(v);

	for (size_t i = 1; i < v.size(); i++) {
		cout << v[i];
	}
	
	for (size_t i = 1; i < v.size(); i++) {
		total += v[i].profit();
	}

	cout << "Total Profit: " << total << ".00" << endl;

	system("PAUSE");
	return 0;
}