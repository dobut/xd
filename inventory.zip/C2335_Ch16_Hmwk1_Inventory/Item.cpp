/*
David Breeden
Chapter 16 HW 1
3/26/28
Item.cpp

Getting the decimals to all be to two spaces and not messing up the other numbers was giving me a lot of trouble so I just left it be :/ 
*/

#include <iomanip>
#include <iostream>
#include <vector>
#include "Item.h"

using namespace std;

Item::Item() {
	id = 0;
}

bool Item::operator>(const Item& a) {
	if (id > a.id)
		return true;
	else
		return false;
	
	return false;
}

bool Item::operator<(const Item& a) {
	if (id < a.id)
		return true;
	else
		return false;

	return false;
}

bool Item::operator>=(const Item& a) {
	if (id >= a.id)
		return true;
	else
		return false;

	return false;
}

bool Item::operator<=(const Item& a) {
	if (id <= a.id)
		return true;
	else
		return false;

	return false;
}

bool Item::operator!=(const Item& a) {
	if (id != a.id)
		return true;
	else
		return false;

	return false;
}

istream &operator>>(istream& input, Item& a) {
	input >> a.id >> a.desc >> a.order >> a.sold >> a.cost >> a.price;

	return input;
}

ostream &operator<<(ostream& output, const Item& a) {
	output << left << setw(6) << a.id << setw(6) << a.desc << setw(6) << a.order << setw(6) << a.sold;
	output << setw(6) << a.cost << setw(6) << a.price << endl;

	return output;
}

int Item::getId() {
	return id;
}

float Item::profit() {
	return sold * (price - cost);
}

Item::~Item() {
}

