/*
David Breeden
Chapter 16 HW 1
3/26/28
Item.h

Getting the decimals to all be to two spaces and not messing up the other numbers was giving me a lot of trouble so I just left it be :/
*/

#pragma once
#include <string>
#include <vector>

using namespace std;

class Item
{
private:
	int id;
	string desc;
	int order;
	int sold;
	float cost;
	float price;
public:
	Item();

	bool operator>(const Item& a);
	bool operator<(const Item& a);
	bool operator>=(const Item& a);
	bool operator<=(const Item& a);
	bool operator!=(const Item& a);
	friend istream &operator>>(istream& input, Item& a);
	friend ostream &operator<<(ostream& output, const Item& a);
	int getId();
	float profit();

	~Item();
};

