/*
David Breeden
Project 2
3/19/18
Play.cpp

Stuff that doesn't work:
-dynamic array (keeps giving me a write access error when I change it, pretty sure it's something simple and I can't see it, so I just set it to 2 groups,
I left the code I wrote for it)
-move check (not sure how to word the logic behind it, I left my attempt at it but it doesn't work right obviously)
-the shuffle adds a zero into the deck for some reason (the default deck doesn't have any zeroes), not sure why it does that

I definitely underestimated this one a bit and started too late, so it's not very pretty. :(

*/

#include <iostream>
#include "Baroness.h"

using namespace std;

int main() {
	int groups = 2;
	bool done = false;
	int one;
	int two;
	char choice;
	
	/*cout << "How many? ";
	cin >> groups;
	cout << endl;*/

	// ask for shuffle
	cout << "Shuffle (y/n)? ";
	cin >> choice;
	cout << endl;

	Baroness game(groups);

	// sets up game and print board
	game.create(choice);
	game.dealCard();
	game.print();

	while (!done) {
		cout << "deal, match, or quit? ";
		cin >> choice;
		cout << endl;

		if (choice == 'd') {
			game.dealCard();
		}
		// checks if input is m and if valid move
		else if (choice == 'm' && game.moveCheck()) {
			cout << "first_pile second_pile? ";
			cin >> one >> two;
			cout << endl;

			// exception loop
			while (true) {
				try {
					game.match(one, two);
					game.removeCard(one);
					game.removeCard(two);
					break;
				}
				catch (invalid_argument& a) {
					cout << "Invalid move, try again" << endl;
				}
				catch (exception e) {
					cout << "something went wrong" << endl;
				}

				cout << "first_pile second_pile (0 0 to go back)?  ";
				cin >> one >> two;
				cout << endl;

				if (one == 0)
					break;
			}
		}
		else
			cout << "No matches" << endl;

		game.print();
	}

	// check if player won
	if (game.winCheck()) {
		cout << "Congratulations -- you win!!!" << endl;
		done = true;
	}
	// check if moves available
	else if (!game.moveCheck()) {
		cout << "No more moves possible -- you lose" << endl;
		done = true;
	}
	// check if input is q
	else if (choice == 'q')
		done = true;

	system("PAUSE");
	return 0;
}