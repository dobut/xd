/*
David Breeden
Project 2
3/19/18
Baroness.h

Stuff that doesn't work:
-dynamic array (keeps giving me a write access error when I change it, pretty sure it's something simple and I can't see it, so I just set it to 2 groups,
I left the code I wrote for it))
-move check (not sure how to word the logic behind it, I left my attempt at it but it doesn't work right obviously)
-the shuffle adds a zero into the deck for some reason (the default deck doesn't have any zeroes), not sure why it does that

I definitely underestimated this one a bit and started too late, so it's not very pretty. :(

*/

#pragma once
#include "Pile.h"
#include "Card.h"

class Baroness :
	public Pile
{
private:
	Pile deck;
	Pile piles[5];
	int size;
public:
	Baroness();
	Baroness(int s);
	void setSize(int s);
	void create(char a);
	void dealCard();
	void removeCard(int a);
	void match(int a, int b);
	void print();
	bool winCheck();
	bool moveCheck();
	~Baroness();
};

