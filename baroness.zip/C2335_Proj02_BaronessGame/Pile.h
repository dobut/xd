/*
David Breeden
Project 2
3/19/18
Pile.h

Stuff that doesn't work:
-dynamic array (keeps giving me a write access error when I change it, pretty sure it's something simple and I can't see it, so I just set it to 2 groups,
I left the code I wrote for it)
-move check (not sure how to word the logic behind it, I left my attempt at it but it doesn't work right)
-the shuffle adds a zero into the deck for some reason (the default deck doesn't have any zeroes), not sure why it does that

I definitely underestimated this one a bit and started too late, so it's not very pretty. :(

*/

#pragma once
#include <iostream>
#include "Card.h"

using namespace std;

class Pile :
	public Card
{
private:
	int pileSize;
	int max;
	Card cards[24];
	//Card* cards;
public:
	Pile();
	Pile(int s);
	void setMax(int s);
	int getCards(int i);
	void addCard(int c);
	int getTop();
	int getPile();
	void shuffle();
	Pile& operator--();
	Pile& operator++();
	friend ostream &operator<<(ostream &out, Pile& c);
	~Pile();
};

