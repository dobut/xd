/*
David Breeden
Project 2
3/19/18
Pile.cpp

Stuff that doesn't work:
-dynamic array (keeps giving me a write access error when I change it, pretty sure it's something simple and I can't see it, so I just set it to 2 groups,
I left the code I wrote for it))
-move check (not sure how to word the logic behind it, I left my attempt at it but it doesn't work right obviously)
-the shuffle adds a zero into the deck for some reason (the default deck doesn't have any zeroes), not sure why it does that

I definitely underestimated this one a bit and started too late, so it's not very pretty. :(

*/

#include <iostream>
#include <algorithm>
#include <stdlib.h>   
#include <time.h> 
#include "Pile.h"

using namespace std;

// default constructor
Pile::Pile() {
	pileSize = 0;
	max = 12;
	//cards = new Card[12];
}

// int constructor
Pile::Pile(int s) {
	pileSize = 0;
	max = s;
	//cards = new Card[s];
}

// sets the max
void Pile::setMax(int s) {
	max = s;
	//cards = new Card[s];
}

// gets value of card i
int Pile::getCards(int i) {
	return cards[i].getValue();
}

// adds card
void Pile::addCard(int c) {
	cards[pileSize].setValue(c);
}

// returns pilesize
int Pile::getPile() {
	return pileSize;
}

// returns top of pile
int Pile::getTop() {
	return cards[pileSize].getValue();
}

// shuffles the pile
void Pile::shuffle() {
	srand(time(NULL));
	
	random_shuffle(begin(cards), end(cards));
}

Pile& Pile::operator--() {
	--pileSize;
	return *this;
}

Pile& Pile::operator++() {
	++pileSize;
	return *this;
}

// prints the cards
ostream& operator<<(ostream& output, Pile& c) {
	for (int i = 1; i <= c.pileSize; i++) {
		cout << "  +----+";
	}
	cout << endl;
	for (int i = 1; i <= c.pileSize; i++) {
		if (c.cards[i].getValue() > 9) {
			cout << "  | " << c.cards[i].getValue() << " |";
		}
		else
			cout << "  |  " << c.cards[i].getValue() << " |";
	}
	cout << endl;
	for (int i = 1; i <= c.pileSize; i++) {
		cout << "  +----+";
	}
	cout << endl;
	return output;
}

Pile::~Pile() {
}
