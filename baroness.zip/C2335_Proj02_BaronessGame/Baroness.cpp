/*
David Breeden
Project 2
3/19/18
Baroness.cpp

Stuff that doesn't work:
-dynamic array (keeps giving me a write access error when I change it, pretty sure it's something simple and I can't see it, so I just set it to 2 groups,
I left the code I wrote for it))
-move check (not sure how to word the logic behind it, I left my attempt at it but it doesn't work right obviously)
-the shuffle adds a zero into the deck for some reason (the default deck doesn't have any zeroes), not sure why it does that

I definitely underestimated this one a bit and started too late, so it's not very pretty. :(

*/

#include "Baroness.h"

//default constructor
Baroness::Baroness() : Pile() {
	size = 12;
}

// int constructor
Baroness::Baroness(int s) : Pile(s * 12) {
	size = s;
}

// sets the size
void Baroness::setSize(int s) {
	size = s;
}

// creates the deck, shuffles if char is y
void Baroness::create(char a) {
	for (int i = 0; i < size; i++) {
		for (int j = 1; j < 13; j++) {
			++deck;
			deck.addCard(j);
			
		}
	}
	
	if (a == 'y')
		deck.shuffle();

}

// deals a card to all piles
void Baroness::dealCard() {
	for (int i = 0; i < 5; i++) {
		if (deck.getPile() != 0) {
			++piles[i];
			piles[i].addCard(deck.getTop());
			--deck;
		}
		else
			continue;
	}
}

// removes a card from a pile
void Baroness::removeCard(int a) {
	--piles[a - 1];
}

// throw exception if no match
void Baroness::match(int a, int b) {
	if ((piles[a - 1].getTop() + piles[b - 1].getTop()) != 13) 
		throw invalid_argument("bad");	
}

// prints piles
void Baroness::print() {
	for (int i = 0; i < 5; i++)
		cout << piles[i];
}

// check if you won
bool Baroness::winCheck() {
	return (deck.getTop() == 0 && piles[0].getTop() == 0 && piles[1].getTop() == 0 && piles[2].getTop() == 0
		&& piles[3].getTop() == 0 && piles[4].getTop() == 0);		
}

// check if legal move (honestly couldn't get my head around how this would work)
bool Baroness::moveCheck() {

	for (int i = 1; i < 5; i++) {
		if (piles[0].getTop() + piles[i].getTop() == 13)
			return true;
	}
	for (int i = 2; i < 5; i++) {
		if (piles[1].getTop() + piles[i].getTop() == 13)
			return true;
	}
	for (int i = 3; i < 5; i++) {
		if (piles[2].getTop() + piles[i].getTop() == 13)
			return true;
	}
	for (int i = 4; i < 5; i++) {
		if (piles[3].getTop() + piles[i].getTop() == 13)
			return true;
	}
	for (int i = 5; i < 5; i++) {
		if (piles[4].getTop() + piles[i].getTop() == 13)
			return true;
	}
	if (deck.getTop() != 0)
		return true;
	else
		return false;
	
}

Baroness::~Baroness() {

}