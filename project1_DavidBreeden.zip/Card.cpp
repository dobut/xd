/*
David Breeden
Project 1
2/12/18
*/

#include <iostream>
#include "Card.h"

using namespace std;

Card::Card()
{
}

// sets front value
void Card::setFront(int c) {
	front = c;
}

// gets front value
int Card::getFront() {
	return front;
}

// sets back value
void Card::setBack(char c) {
	back = c;
}

// prints top/bottom of card
void Card::printCardTopBottom() {
	cout << "+---+";
}

// prints value of front/back if card is up or down
void Card::print() {
	if (isUp)
		cout << "| " << front << " |";
	else
		cout << "| " << back << " |";
}

// check if card is up or down
bool Card::isCardUp() {	
	if (isUp)
		return true;
	else
		return false;
}

// turns card up
void Card::turnUp() {
	isUp = true;
}

// turns card down
void Card::turnDown() {
	isUp = false;
}

Card::~Card()
{
}
