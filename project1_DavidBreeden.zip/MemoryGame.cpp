/*
David Breeden
Project 1
2/12/18
*/

#include <iostream>
#include <algorithm>
#include <stdlib.h>   
#include <time.h> 
#include "MemoryGame.h"
#include "Card.h"

using namespace std;

MemoryGame::MemoryGame()
{
}

// resets the game with choice of random shuffle or regular order
void MemoryGame::resetGame(bool randomShuffle) {
	int c = 0;
	srand(time(NULL));

	// random shuffle 
	if (randomShuffle) {
		// the inner loop iterates twice, though it doesn't like (j + 2) so i just did another ++ at the end
		for (int i = 0; i < MAXDECK; i++) {
			for (int j = 0; j < MAXDECK; j++) {															
				cards[i][j].setBack('*');
				cards[i][j].turnDown();
				cards[i][j + 1].setBack('*');
				cards[i][j + 1].turnDown();
				cards[i][j].setFront(1 + c);
				cards[i][j + 1].setFront(1 + c);
				j++;
				c++;

			}
		}

		// what i did to get it to shuffle was creating another array and filling it with front values from cards, shuffling that array,
		// then copying that array back over with setfront
		for (int i = 0; i < MAXDECK; i++) {
			for (int j = 0; j < MAXDECK; j++) {
				shuffle[i][j] = cards[i][j].getFront();
			}
		}
	
		random_shuffle(&shuffle[0][0], &shuffle[0][0] + MAXDECK*MAXDECK);

		for (int i = 0; i < MAXDECK; i++) {
			for (int j = 0; j < MAXDECK; j++) {
				cards[i][j].setFront(shuffle[i][j]);
			}
		}	
	}
	// default reset
	else {
		for (int i = 0; i < MAXDECK; i++) {
			for (int j = 0; j < MAXDECK; j++) {
				cards[i][j].setBack('*');
				cards[i][j].turnDown();
				cards[i][j + 1].setBack('*');
				cards[i][j + 1].turnDown();
				cards[i][j].setFront(1 + c);
				cards[i][j + 1].setFront(1 + c);
				j++;
				c++;
			}
		}
	}
}

// prints the board 
void MemoryGame::printBoard() {
	for (int i = 0; i < MAXDECK; i++) {
		for (int j = 0; j < MAXDECK; j++) {
			cards[i][j].printCardTopBottom();
		}
		cout << endl;
		for (int k = 0; k < MAXDECK; k++) {
			cards[i][k].print();
		}
		cout << endl;
		for (int l = 0; l < MAXDECK; l++) {
			cards[i][l].printCardTopBottom();
		}
		cout << endl;
	}
}

// gets the first card from user
void MemoryGame::getFirstCard() {
	// prompt
	cout << "Row Column? ";
	cin >> firstRow >> firstCol;
	cout << endl;

	// while card is already up or invalid number, print invalid or card is already up then prompt for another value
	while ((cards[firstRow - 1][firstCol - 1].isCardUp()) || (firstRow == 0 || firstCol == 0) || (firstRow > MAXDECK || firstCol > MAXDECK)) {
		if ((firstRow == 0 || firstCol == 0) || (firstRow > MAXDECK || firstCol > MAXDECK)) {
			cout << "Invalid row and/or column" << endl;
			cout << "Row Column? ";
			cin >> firstRow >> firstCol;
			cout << endl;
			break;
		}
		
		if (cards[firstRow - 1][firstCol - 1].isCardUp()) {
			cout << "Card is already face up" << endl;
			cout << "Row Column? ";
			cin >> firstRow >> firstCol;
			cout << endl;
		}
	
	}

	// adjust values back
	firstRow--;
	firstCol--;

	// turn up card
	cards[firstRow][firstCol].turnUp();
}

// get the second card from user, same as first card
void MemoryGame::getSecondCard() {
	cout << "Row Column? ";
	cin >> secondRow >> secondCol;
	cout << endl;

	while (cards[secondRow - 1][secondCol - 1].isCardUp() || (secondRow == 0 || secondCol == 0) || (secondRow > MAXDECK || secondCol > MAXDECK)) {
		if (cards[secondRow - 1][secondCol - 1].isCardUp()) {
			cout << "Card is already face up" << endl;
			cout << "Row Column? ";
			cin >> secondRow >> secondCol;
			cout << endl;
		}

		if ((secondRow == 0 || secondCol == 0) || (secondRow > MAXDECK || secondCol > MAXDECK)) {
			cout << "Invalid row and/or column" << endl;
			cout << "Row Column? ";
			cin >> secondRow >> secondCol;
			cout << endl;
		}
	}

	secondRow--;
	secondCol--;

	cards[secondRow][secondCol].turnUp();
}

// if the cards match return true, else return false
bool MemoryGame::cardsMatch() {
	if (cards[firstRow][firstCol].getFront() == cards[secondRow][secondCol].getFront()) {
		numMatches++;
		return true;	
	}
	else
		return false;
}

// ends the turn
void MemoryGame::endTurn() {
	// increment guesses
	numGuesses++;

	// if cards aren't matching print try again and turn down the two cards
	if (!(cards[firstRow][firstCol].getFront() == cards[secondRow][secondCol].getFront())) {
		cards[firstRow][firstCol].turnDown();
		cards[secondRow][secondCol].turnDown();
		cout << "Try again" << endl << endl << endl;
	}

	// if guesses are max end the game
	if (numGuesses == MAXGUESSES) {
		status = 1;
		cout << "You lost!" << endl;
	}
	// if all cards are matched end the game
	if (numMatches == MAXDECK * 2) {
		status = 2;
		cout << "You won with " << numGuesses << " guesses!" << endl;
	}
}

// gets the current game status (0 = continue, 1 = lose, 2 = win)
int MemoryGame::getStatus() {
	return status;
}

// returns number of guesses
int MemoryGame::numGuessesMade() {
	return numGuesses;
}

MemoryGame::~MemoryGame()
{
}
