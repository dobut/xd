/*
David Breeden
Project 1
2/12/18
*/

#pragma once

class Card
{
	int front;
	char back;
	bool isUp;

public:
	

	Card();
	~Card();

	void setFront(int c);
	int getFront();
	void setBack(char c);

	void printCardTopBottom();
	void print();

	bool isCardUp();
	void turnUp();
	void turnDown();
};

