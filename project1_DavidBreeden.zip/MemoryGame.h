/*
David Breeden
Project 1
2/12/18
*/

#pragma once
#include "Card.h"

class MemoryGame
{
	static const int MAXDECK = 4, MAXGUESSES = 15;

	Card cards[MAXDECK][MAXDECK];
	int shuffle[MAXDECK][MAXDECK]; // extra array for resetgame function
	int numGuesses = 0, numMatches = 0, firstRow = 0, firstCol = 0, secondRow = 0, secondCol = 0;

	// i wasn't able to get the enum in the sample to work so i just used an int, 0 = continue, 1 = lose, 2 = win
	int status = 0;

public:
	MemoryGame();
	~MemoryGame();
	
	void resetGame(bool randomShuffle);

	void printBoard();
	void getFirstCard();
	void getSecondCard();
	bool cardsMatch();
	void endTurn();
	int getStatus();
	int numGuessesMade();
};

