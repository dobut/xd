/*
David Breeden
Project 1
2/12/18
*/

#include <iostream>
#include "Card.h"
#include "MemoryGame.h"

using namespace std;

int main() {
	Card c;
	MemoryGame g;
	char i;
	// initialize bool to false
	bool random = false;

	cout << "Random Shuffle (y/n)? ";
	cin >> i;
	cout << endl;
	
	// if input is y change random to true
	if (i == 'y')
		random = true;

	// reset game with random as parameter
	g.resetGame(random);	

	// game loop, with getstatus as parameter, 0 = continue, 1 = lose, 2 = win
	while (g.getStatus() == 0) {
		g.printBoard();

		g.getFirstCard();

		g.printBoard();

		g.getSecondCard();

		g.printBoard();

		// card match
		if (g.cardsMatch())
			cout << "You made a match!" << endl << endl << endl;

		g.endTurn();
	}
	
	system("PAUSE");
	return 0;
}