/*
David Breeden
Chapter 17 Homework 1
4/2/18
Color.h
*/

#pragma once
#include <string>

using namespace std;

class Color
{
private:
	string name;
	int red, green, blue;
public:
	Color();
	void setName(string s);
	void setRed(int r);
	void setGreen(int g);
	void setBlue(int b);
	string getName();
	int getRed();
	int getGreen();
	int getBlue();

	friend bool operator==(Color c, Color d);
	friend bool operator!=(Color c, Color d);
	friend ostream &operator<<(ostream &output, Color &c);

	~Color();
};

