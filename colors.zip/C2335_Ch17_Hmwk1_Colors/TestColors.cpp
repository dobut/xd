/*
David Breeden
Chapter 17 Homework 1
4/2/18
TestColors.cpp
*/

#include <iostream>
#include <string>
#include "unorderedLinkedList.h"
#include "Color.h"

using namespace std;

int main() {
	unorderedLinkedList<Color> list;
	Color c;
	int choice = 0;
	string name;
	int red, green, blue;

	// while loop
	while (choice != 5) {
		cout << "1 - add" << endl << "2 - print" << endl << "3 - delete" << endl << "4 - search" << endl << "5 - quit" << endl << "Choice? ";
		cin >> choice;
		cout << endl;

		// switch for different choices
		switch (choice) {
		case 1:
			cout << "Name red green blue? ";
			cin >> name >> red >> green >> blue;
			cout << endl;
			c.setName(name);
			c.setRed(red);
			c.setGreen(green);
			c.setBlue(blue);
			list.insertLast(c);
			break;
		case 2:
			cout << "Colors:" << endl;
			list.print();
			cout << endl;
			break;
		case 3:
			cout << "Name? ";
			cin >> name;
			cout << endl;
			c.setName(name);
			if (list.search(c))
				list.deleteNode(c);
			else
				cout << "Color not found" << endl;
			break;
		case 4:
			cout << "Name? ";
			cin >> name;
			cout << endl;
			c.setName(name);
			if (list.search(c))
				cout << "Color found" << endl;
			else
				cout << "Color not found" << endl;
			break;
		}
	}

	system("PAUSE");
	return 0;
}