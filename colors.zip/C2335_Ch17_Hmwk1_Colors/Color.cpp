/*
David Breeden
Chapter 17 Homework 1
4/2/18
Color.cpp
*/

#include "Color.h"

Color::Color() {
}

void Color::setName(string s) {
	name = s;
}

void Color::setRed(int r) {
	red = r;
}

void Color::setGreen(int g) {
	green = g;
}

void Color::setBlue(int b) {
	blue = b;
}

string Color::getName() {
	return name;
}

int Color::getRed() {
	return red;
}

int Color::getGreen() {
	return green;
}

int Color::getBlue() {
	return blue;
}

bool operator==(Color c, Color d) {
	return (c.getName() == d.getName());
}
bool operator!=(Color c, Color d){
	return (c.getName() != d.getName());
}
ostream &operator<<(ostream &output, Color &c) {
	output << " " << c.getName() << " = (" << c.getRed() << ", " << c.getGreen() << ", " << c.getBlue() << ")" << endl;

	return output;
}


Color::~Color() {
}
